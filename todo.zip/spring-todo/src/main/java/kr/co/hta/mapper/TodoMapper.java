package kr.co.hta.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.co.hta.vo.Todo;

@Mapper
public interface TodoMapper {

	List<Todo> getTodos(String userId);
	Todo getTodoByNo(int todoNo);
	void insertTodo(Todo todo);
	void updateTodo(Todo todo);
}
