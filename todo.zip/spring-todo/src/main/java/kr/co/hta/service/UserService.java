package kr.co.hta.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;

import kr.co.hta.exception.ApplicationException;
import kr.co.hta.mapper.UserMapper;
import kr.co.hta.vo.User;
import kr.co.hta.web.form.UserRegisterForm;

@Service
public class UserService {

	@Autowired
	private UserMapper userMapper;
	
public void addNewUser(UserRegisterForm userRegisterForm) throws Exception {
		
		User user = userMapper.getUserByEmail(userRegisterForm.getEmail());
		if (user != null) {
			throw new ApplicationException("이미 사용중인 이메일입니다.");
		}		
		
		user = new User();
		BeanUtils.copyProperties(userRegisterForm, user);	// email, password, name, phone값이 User로 복사된다.
		user.setId(UUID.randomUUID().toString());
		
		userMapper.insertUser(user);		
	}

	public User login(String email, String password) {
		User user = userMapper.getUserByEmail(email);
		if (user == null) {
			throw new ApplicationException("아이디 혹은 비밀번호가 올바르지 않습니다.");
		}
		if (!user.getPassword().equals(password)) {
			throw new ApplicationException("아이디 혹은 비밀번호가 올바르지 않습니다.");			
		}
		return user;
	}
}
