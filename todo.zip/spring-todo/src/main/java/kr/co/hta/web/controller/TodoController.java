package kr.co.hta.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.hta.annotation.LoginUser;
import kr.co.hta.service.TodoService;
import kr.co.hta.vo.User;
import kr.co.hta.web.form.TodoForm;

@Controller
@RequestMapping("/todo")
public class TodoController {

	@Autowired
	private TodoService todoService;
	
	/**
	 * 로그인한 사용자의 할일 목록 요청을 처리한다.
	 * 로그인한 사용자 아이디로 등록된 모든 할일을 조회해서 모델객체에 저장하고, 뷰페이지를 반환한다.
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param model 할일목록을 저장하는 모델객체를 전달받는다.
	 * @return 할일 목록 화면(todo/list.jsp)에 대한 뷰페이지 이름을 반환한다.
	 */
	@GetMapping("/list")
	public String list(@LoginUser User user, Model model) {
		return "todo/list";
	}
	
	/**
	 * 새 할일 등록 화면 요청을 처리한다.
	 * @return 새 할일 등록 화면(todo/form.jsp)에 대한 뷰 페이지 이름을 반환한다.
	 */
	@GetMapping("/form")
	public String form() {
		return "todo/form";
	}
	
	/**
	 * 새 할일 등록요청을 처리한다.
	 * Todo객체를 생성해서 로그인한 사용자정보와 새 할일정보를 저장하고, TodoService의 addNewTodo(Todo todo)메소드를 호출한다.
	 * 할일 목록을 요청하는 재요청 URL을 응답으로 보낸다.
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param todoForm 새 할일등록폼에서 입력한 할일정보가 저장된 TodoForm객체를 전달받는다.
	 * @return 할일 목록화면을 요청하는 재요청URL을 응답으로 보낸다.
	 */
	@PostMapping("/insert") 
	public String insert(@LoginUser User user, TodoForm todoForm) {
		
		return "redirect:list";
	}
	
	/**
	 * 할일 상세 화면 요청을 처리한다.
	 * 요청파라미터로 전달받은 할일번호에 해당하는 할일정보를 조회해서 모델객체에 저장하고, 뷰페이지를 반환한다
	 * 
	 * @param no 요청파라미터로 전달된 할일번호를 전달받는다.
	 * @param model  할일정보을 저장하는 모델객체를 전달받는다.
	 * @return 새 할일 상세 화면(todo/detail.jsp)에 대한 뷰 페이지 이름을 반환한다.
	 */
	@GetMapping("/detail")
	public String list(@RequestParam("no") int no,  Model model) {
		
		return "todo/detail";
	}
	
	/**
	 * 할일 수정화면 요청을 처리한다.
	 * 요청파라미터로 전달받은 할일번호에 해당하는 할일 정보를 조회해서 모델객체에 저장하고, 뷰페이지를 반환한다.
     * 로그인한 사용자 번호와 할일 작성자의 사용자 번호가 다르면 상세페이지를 재요청하는 URL을 응답으로 보낸다. "redirect:/detail?no=10&fail=deny" 
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param no 요청파라미터로 전달된 할일번호를 전달받는다
	 * @param model 할일정보을 저장하는 모델객체를 전달받는다.
	 * @return 할일 수정 화면(todo/modifyform.jsp)에 대한 뷰 페이지 이름을 반환한다.
	 */
	@GetMapping("/modify")
	public String modifyform(@LoginUser User user, @RequestParam("no") int no,  Model model) {
		
		return "todo/modifyform";
	}
	
	/**
	 * 할일 수정요청을 처리한다.
	 * 요청파라미터로 전달받은 할일번호와 할일 수정폼에서 입력한 값을 TodoForm객체로 전달받는다.
	 * Todo객체를 생성해서 할일번호, 수정된 할일 정보, 사용자 정보를 담고, TodoService의 updateTodoInfo(Todo todo) 메소드를 호출한다.
	 * 할일상세 화면을 재요청하는 url을 응답으로 보낸다.
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param no 수정된 할일번호를 전달받는다.
	 * @param todoForm 할일 수정폼에서 수정한 할일 정보가 저장된 TodoForm객체르를 전달받는다.
	 * @return 할일 상세화면을 요청하는 재요청URL을 응답으로 보낸다.
	 */
	@PostMapping("/modify")
	public String modify(@LoginUser User user, @RequestParam("no") int no, TodoForm todoForm) {
		
		return "redirect:/detail?no=" + no;
	}
	
	/**
	 * 할일 정보 삭제 요청을 처리한다.
	 * 전달받는 사용자정보와 할일번호를 TodoService의 deleteTodo(String userId, int no) 메소드를 실행한다
	 * 할일목록 화면을 재요청하는 url을 응답으로 보낸다.
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param no 삭제할 할일번호를 전달받는다.
	 * @return 할일 목록화면을 요청하는 재요청URL을 응답으로 보낸다.
	 */
	@GetMapping("/delete")
	public String list(@LoginUser User user, @RequestParam("no") int no) {
		
		return "redirect:list";
	}
	
	/**
	 * 할일 정보 완료처리 요청을 처리한다.
	 * 전달받는 사용자정보와 할일번호를 TodoService의 completeTodo(String userId, int no) 메소드를 실행한다
	 * 할일목록 화면을 재요청하는 url을 응답으로 보낸다.
	 * 
	 * @param user 세션에 저장된 로그인된 사용자 정보를 전달받는다.
	 * @param no 완료처리할 할일번호를 전달받는다.
	 * @return 할일 목록화면을 요청하는 재요청URL을 응답으로 보낸다.
	 */
	@GetMapping("/complete")
	public String complete(@LoginUser User user, @RequestParam("no") int no) {
		
		return "redirect:list";
	}
	
}
