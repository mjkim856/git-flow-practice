package kr.co.hta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.hta.mapper.CategoryMapper;
import kr.co.hta.mapper.TodoMapper;
import kr.co.hta.mapper.UserMapper;
import kr.co.hta.vo.Category;
import kr.co.hta.vo.Todo;

@Service
public class TodoService {

	@Autowired
	private CategoryMapper categoryMapper;
	@Autowired
	private TodoMapper todoMapper;
	@Autowired
	private UserMapper userMapper;
	
	/**
	 * 모든 카테고리 목록을 반환한다.
	 * @return 카테고리 목록
	 */
	public List<Category> getAllCategories() {
		return null;
	}
	
	/**
	 * 지정된 사용자 아이디에 해당하는 사용자가 작성할 할일 목록을 반환한다.
	 * @param userId 사용자 아이디
	 * @return 할일 목록
	 */
	public List<Todo> getAllMyTodos(String userId) {
		return null;
	}
	
	/**
	 * 지정된 사용자번호에 해당하는 할일정보를 반환한다.
	 * @param todoNo 할일 번호
	 * @return 할일정보
	 */
	public Todo getTodoDetail(int todoNo) {
		return null;
	}
	
	/**
	 * 지정된 할일정보를 전달받아서 저장시킨다.
	 * @param todo 새 할일정보
	 */
	public void addNewTodo(Todo todo) {
		
	}
	
	/**
	 * 수정된 정보가 포함된 할일정보를 전달받아서 할일정보를 수정한다.
	 * @param todo 수정된 정보가 포함될 할일정보
	 */
	public void updateTodoInfo(Todo todo) {
		
	}
	
	/**
	 * 사용자 아이디와 할일번호를 전달받아서 할일정보를 삭제상태로 변경한다.
	 * 사용자 아이디와 삭제할 할일정보의 작성자아이디가 다르면 예외를 발생시킨다.
	 * @param userId 사용자 아이디
	 * @param no 할일번호
	 */
	public void deleteTodo(String userId, int no) {
		
	}
	
	/**
	 * 사용자 아이디와 할일번호를 전달받아서 할일정보를 처리완료상태로 변경한다.
	 * 사용자 아이디와 할일정보의 작성자아이디가 다르면 예외를 발생시킨다.
	 * @param userId 사용자 아이디
	 * @param no 할일번호
	 */
	public void completetodo(String userId, int no) {
		
	}
	
	
}
