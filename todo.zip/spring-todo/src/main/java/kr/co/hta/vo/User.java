package kr.co.hta.vo;

import java.util.Date;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.ToString;
import lombok.Setter;

@Getter
@Setter
@ToString
@Alias("User")
public class User {

	private String id;
	private String email;
	private String password;
	private String name;
	private String tel;
	private String disabled;
	private Date createdDate;
	private Date updatedDate;
}
