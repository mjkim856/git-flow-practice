package kr.co.hta.vo;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Alias("Category")
public class Category {

	private String id;
	private String name;
}
