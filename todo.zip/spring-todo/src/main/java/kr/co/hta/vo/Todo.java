package kr.co.hta.vo;

import java.util.Date;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.ToString;
import lombok.Setter;

@Getter
@Setter
@ToString
@Alias("Todo")
public class Todo {

	private int no;
	private String title;
	private Date dueDate;
	private String description;
	private String completed;
	private Date completedDate;
	private Date updatedDate;
	private Date createdDate;
	private Category category;
	private User user;
}
